﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIK299_Mahamud_Abdullahi_labb3._0
{
    public struct Hair
    {
        public string hairlength;
        public string haircolor;
    }
}
